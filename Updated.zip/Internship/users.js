const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const passport = require('passport');
const validator = require('validator');
const jwt = require('jsonwebtoken');
const winston = require('winston');
const rateLimit = require('express-rate-limit');
const User = require('../models/User');
const { forwardAuthenticated } = require('../config/auth');

// ✅ Use JWT Secret from .env
const jwtSecret = process.env.JWT_SECRET;

// ✅ Winston Logger Setup
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({ timestamp, level, message }) => `${timestamp} ${level}: ${message}`)
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'security.log' })
  ]
});

logger.info('Logger initialized');

// ✅ Rate Limiter for Login Route
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5,
  handler: (req, res) => {
    logger.warn(`Possible brute force attempt from IP: ${req.ip}`);
    res.status(429).json({ msg: 'Too many login attempts. Please try again later.' });
  }
});

// ✅ JWT Authentication Middleware
const authenticateJWT = (req, res, next) => {
  const token = req.header('Authorization');
  if (!token) return res.status(401).json({ msg: 'Access denied. No token provided.' });

  try {
    const decoded = jwt.verify(token.replace('Bearer ', ''), jwtSecret);
    req.user = decoded;
    next();
  } catch (err) {
    res.status(403).json({ msg: 'Invalid token' });
  }
};

// ✅ Login Page
router.get('/login', forwardAuthenticated, (req, res) => res.render('login'));

// ✅ Register Page
router.get('/register', forwardAuthenticated, (req, res) => res.render('register'));

// ✅ Register Handler
router.post('/register', async (req, res) => {
  const { name, email, password, password2 } = req.body;
  let errors = [];

  if (!name || !email || !password || !password2) {
    errors.push({ msg: 'Please enter all fields' });
  }
  if (!validator.isEmail(email)) {
    errors.push({ msg: 'Invalid email format' });
  }
  if (!validator.isAlphanumeric(name.replace(/\s/g, ''))) {
    errors.push({ msg: 'Name must contain only letters and numbers' });
  }
  if (password !== password2) {
    errors.push({ msg: 'Passwords do not match' });
  }
  if (password.length < 6) {
    errors.push({ msg: 'Password must be at least 6 characters' });
  }

  if (errors.length > 0) {
    return res.render('register', { errors, name, email, password, password2 });
  }

  try {
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.render('register', {
        errors: [{ msg: 'Email already exists' }],
        name,
        email,
        password,
        password2
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ name, email, password: hashedPassword });

    await newUser.save();
    req.flash('success_msg', 'You are now registered and can log in');
    res.redirect('/users/login');

  } catch (err) {
    logger.error(`Error during registration: ${err.message}`);
    res.render('register', {
      errors: [{ msg: 'Error saving user. Please try again.' }],
      name,
      email,
      password,
      password2
    });
  }
});

// ✅ Login with JWT + Winston Logging
router.post('/login', loginLimiter, (req, res, next) => {
  passport.authenticate('local', async (err, user, info) => {
    if (err || !user) {
      logger.warn(`Failed login attempt for ${req.body.email} from IP: ${req.ip}`);
      return res.status(401).json({ msg: 'Invalid credentials' });
    }

    logger.info(`User logged in: ${user.email} (IP: ${req.ip})`);

    const token = jwt.sign(
      { id: user._id, email: user.email },
      jwtSecret,
      { expiresIn: '1h' }
    );

    res.json({ token });
  })(req, res, next);
});

// ✅ Protected Route (JWT Required)
router.get('/dashboard', authenticateJWT, (req, res) => {
  logger.info(`Dashboard accessed by: ${req.user.email} (IP: ${req.ip})`);
  res.json({ msg: 'Welcome to your dashboard', user: req.user });
});

// ✅ Secure Logout
router.get('/logout', (req, res, next) => {
  req.logout((err) => {
    if (err) return next(err);
    req.flash('success_msg', 'You are logged out');
    res.redirect('/users/login');
  });
});

module.exports = router;
