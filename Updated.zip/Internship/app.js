// Load Environment Variables from .env
require('dotenv').config();

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const expressLayouts = require('express-ejs-layouts');
const mongoose = require('mongoose');
const passport = require('passport');
const flash = require('connect-flash');
const winston = require('winston');
const session = require('express-session');

const app = express();

// ✅ Secure HTTP Headers
app.use(helmet());

// ✅ Cross-Origin Resource Sharing (Only allow trusted frontends)
app.use(cors({
  origin: 'http://localhost:3000', // Change this for your frontend
  methods: ['GET', 'POST'],
  credentials: true
}));

// ✅ Winston Logger
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({ timestamp, level, message }) => `${timestamp} ${level}: ${message}`)
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'security.log' })
  ]
});

logger.info('Application started');

// ✅ MongoDB Connection
const db = process.env.DB_URI;
mongoose
  .connect(db, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    serverSelectionTimeoutMS: 5000
  })
  .then(() => console.log('✅ MongoDB Connected'))
  .catch(err => console.error(`❌ MongoDB Connection Error: ${err.message}`));

// ✅ Passport Config
require('./config/passport')(passport);

// ✅ View Engine (EJS + Layouts)
app.use(expressLayouts);
app.set('view engine', 'ejs');

// ✅ Body Parser
app.use(express.urlencoded({ extended: true }));

// ✅ Express Session
app.use(
  session({
    secret: 'secret', // replace with a .env secret if needed
    resave: true,
    saveUninitialized: true,
    cookie: { secure: process.env.NODE_ENV === 'production' }
  })
);

// ✅ Passport Middleware
app.use(passport.initialize());
app.use(passport.session());

// ✅ Flash Messages
app.use(flash());

// ✅ Global Flash Message Variables
app.use((req, res, next) => {
  res.locals.success_msg = req.flash('success_msg');
  res.locals.error_msg = req.flash('error_msg');
  res.locals.error = req.flash('error');
  next();
});

// ✅ Routes
app.use('/', require('./routes/index.js'));
app.use('/users', require('./routes/users.js'));

// ✅ Start Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));
